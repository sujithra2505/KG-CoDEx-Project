const { chromium } = require('playwright');
const OUT = process.argv[2];
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1500, height: 950 }, deviceScaleFactor: 2 });
  const errs=[]; p.on('pageerror', e=>errs.push(String(e)));
  // Cap dashboard
  await p.goto('http://localhost:8765/outputs/cap_comparison_dashboard/index.html');
  await p.waitForTimeout(1500);
  await p.screenshot({ path: OUT+'/dash_full.png', fullPage: true });
  // Explorer
  await p.goto('http://localhost:8765/outputs/prediction_ui/index.html');
  await p.waitForTimeout(5000);
  console.log('status:', await p.textContent('#load-status'));
  await p.screenshot({ path: OUT+'/ex_graph_default.png' });
  console.log('errors', errs);
  await b.close();
})();
