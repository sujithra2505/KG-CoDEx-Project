import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import sys
OUT=sys.argv[1]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5})
# (task, start, end, kind) in week units; W1 = week of 29 Jun 2026; W18 = 26 Oct-1 Nov; W19 = 2 Nov; m1..m6 = 20..25
T=[('1. Literature review and paper inventory',1,16,'approx'),
('2. Problem formulation and comparison',8,16,'approx'),
('3. Earlier FB15K-237 prototype (superseded)',13,18,'approx'),
('4. CoDEx-M dataset inspection (Phase 1)',18,19,'dated'),
('5. Training graph and viewer (Phase 2)',18,19,'dated'),
('6. RDF/OWL ontology dataset (Phase 3)',18,19,'dated'),
('7. Rule mining and validation review (Phase 4)',18,19,'dated'),
('8. Candidates, V1/V2 ranking (Phase 5)',18,19,'dated'),
('9. Prediction explorer',18,19,'dated'),
('10. Cap-100 test evaluation (Phase 6)',18,19,'dated'),
('11. Cap experiment and final test',18,19,'dated'),
('12. Cap-comparison dashboard',18,19,'dated'),
('13. Phase 1 report preparation',18,20,'ongoing'),
('14. Ontology-aware scoring and ablation',20,23,'planned'),
('15. Ranking protocol (MRR, Hits@K)',21,24,'planned'),
('16. Embedding baselines and final report',23,26,'planned')]
col={'approx':'#9ccf9c','dated':'#2e8b2e','ongoing':'#eda100','planned':'#2a78d6'}
fig,ax=plt.subplots(figsize=(10,5.2))
for i,(t,s,e,k) in enumerate(T):
    ax.barh(i,e-s,left=s,color=col[k],height=0.6,edgecolor='white')
ax.set_yticks(range(len(T))); ax.set_yticklabels([t[0] for t in T]); ax.invert_yaxis()
ticks=[1,5,9,13,18]+[20,21,22,23,24,25]
labs=['W1\nJul','W5\nAug','W9\nAug','W13\nSep','W18\n26 Oct','m1','m2','m3','m4','m5','m6']
ax.set_xticks([x+0.0 for x in ticks]); ax.set_xticklabels(labs,fontsize=7.5)
ax.set_xlim(1,26); ax.xaxis.grid(True,color='#e4e3df'); ax.set_axisbelow(True)
ax.axvline(20,color='#e34948',linewidth=1.2,linestyle='--'); ax.text(20.1,-0.8,'end of Phase 1',color='#e34948',fontsize=7.5)
for s in ['top','right']: ax.spines[s].set_visible(False)
ax.legend(handles=[Patch(color=col['dated'],label='Completed (dated project files)'),Patch(color=col['approx'],label='Completed (period approximate)'),
 Patch(color=col['ongoing'],label='In progress'),Patch(color=col['planned'],label='Planned (relative months, to be confirmed)')],
 loc='lower left',fontsize=7.5,frameon=False,ncol=2,bbox_to_anchor=(0,-0.32))
fig.tight_layout(); fig.savefig(OUT+'/gantt.png',dpi=220)
