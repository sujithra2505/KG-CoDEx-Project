const { chromium } = require('playwright');
const OUT = process.argv[2];
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1500, height: 950 }, deviceScaleFactor: 2 });
  const errs=[]; p.on('pageerror', e=>errs.push(String(e)));
  await p.goto('http://localhost:8765/outputs/cap_comparison_dashboard/index.html');
  await p.waitForTimeout(1500);
  await (await p.$('#charts')).screenshot({ path: OUT+'/dash_charts.png' });
  await (await p.$('#val-table')).screenshot({ path: OUT+'/dash_valtable.png' });
  await (await p.$('#test-table')).screenshot({ path: OUT+'/dash_testtable.png' });
  await (await p.$('#summary')).screenshot({ path: OUT+'/dash_summary.png' });

  await p.goto('http://localhost:8765/outputs/prediction_ui/index.html');
  await p.waitForTimeout(5000);
  // table tab, filter v2, relation P26
  await p.selectOption('#f-version','v2');
  await p.click('#tabs button[data-tab=table]');
  await p.waitForTimeout(800);
  await p.selectOption('#f-relation','P26').catch(e=>console.log('rel',e.message));
  await p.waitForTimeout(800);
  await p.screenshot({ path: OUT+'/ex_table.png' });
  // click first row -> detail + graph
  await p.click('#pred-table tbody tr[data-pid]');
  await p.waitForTimeout(2500);
  await p.click('#focus-btn');
  await p.waitForTimeout(3000);
  await p.screenshot({ path: OUT+'/ex_evidence.png' });
  // entity view
  await p.goto('http://localhost:8765/outputs/prediction_ui/index.html');
  await p.waitForTimeout(5000);
  await p.fill('#f-entity','Katherine Jackson');
  await p.waitForTimeout(800);
  await p.keyboard.press('Enter');
  await p.waitForTimeout(4000);
  await p.screenshot({ path: OUT+'/ex_entity.png' });
  // compare tab
  await p.click('#tabs button[data-tab=compare]');
  await p.waitForTimeout(1500);
  await p.screenshot({ path: OUT+'/ex_compare.png' });
  await p.click('#tabs button[data-tab=evaluation]');
  await p.waitForTimeout(2500);
  await p.screenshot({ path: OUT+'/ex_eval.png' });
  // phase2 graph
  await p.goto('http://localhost:8765/outputs/phase2/interactive_graph.html');
  await p.waitForTimeout(6000);
  await p.fill('#entity-search','Katherine Jackson');
  await p.click('#entity-search-button'); await p.waitForTimeout(800);
  await p.click('#neighborhood-button'); await p.waitForTimeout(6000);
  await p.screenshot({ path: OUT+'/p2_neigh.png' });
  console.log('errors', errs);
  await b.close();
})();
