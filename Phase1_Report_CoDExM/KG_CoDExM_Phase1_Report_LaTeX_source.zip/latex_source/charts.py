import json, sys
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
R='/mnt/user-data/uploads/KG-Ontology-Rule-Based-Project/outputs/'
OUT=sys.argv[1]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.edgecolor':'#9a9994','axes.labelcolor':'#52514e',
 'xtick.color':'#52514e','ytick.color':'#52514e','axes.spines.top':False,'axes.spines.right':False,'text.color':'#0b0b0b'})
C=['#2a78d6','#eb6834','#1baf7a']
GRID='#e4e3df'
e=json.load(open(R+'phase6/evaluation_test/evaluation_results.json'))
t=json.load(open(R+'cap_experiment/test_final/test_results.json'))['overall']
cfg={'Cap 100 V1':e['versions']['v1']['overall'],'Cap 100 V2':e['versions']['v2']['overall'],'Cap 1,000 V2':t}
names=list(cfg)
# verify
for n,o in cfg.items():
    assert o['predictions']==o['tp_matched_positives']+o['fp_matched_supplied_negatives']+o['unlabelled_predictions']
    print(n,o['predictions'],o['tp_matched_positives'],o['fp_matched_supplied_negatives'],o['unlabelled_predictions'],o['precision'],o['recall'],o['f1'],o['positive_hit_rate'])
def bars(ax,vals,title,pct=False):
    xs=range(len(vals))
    b=ax.bar(xs,vals,color=C,width=0.62,edgecolor='white',linewidth=1.5)
    for x,v in zip(xs,vals):
        ax.text(x,v,(f'{v*100:.2f}%' if pct else f'{v:,}'),ha='center',va='bottom',fontsize=8,color='#0b0b0b')
    ax.set_xticks(list(xs)); ax.set_xticklabels(names,fontsize=7.5)
    ax.set_title(title,fontsize=9.5,loc='left',color='#0b0b0b',fontweight='bold')
    ax.yaxis.grid(True,color=GRID,linewidth=0.8); ax.set_axisbelow(True)
    ax.set_ylim(0,max(vals)*1.18)
    ax.yaxis.set_major_locator(matplotlib.ticker.MaxNLocator(5))
    if pct: ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0,decimals=0 if max(vals)>0.3 else 1))
    else: ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda x,p: f'{int(x):,}'))
fig,axs=plt.subplots(2,4,figsize=(11,5.4))
keys=[('predictions','Predictions',0),('tp_matched_positives','Positive test matches (TP)',0),('fp_matched_supplied_negatives','Supplied-negative matches (FP)',0),('unlabelled_predictions','Unlabelled predictions',0),
('precision','Benchmark precision',1),('recall','Recall',1),('f1','F1-score',1),('positive_hit_rate','Positive hit rate',1)]
for ax,(k,tl,p) in zip(axs.flat,keys): bars(ax,[cfg[n][k] for n in names],tl,bool(p))
fig.tight_layout(); fig.savefig(OUT+'/chart_test_comparison.png',dpi=220); plt.close(fig)
# validation across caps
v=json.load(open(R+'cap_experiment/validation/validation_results.json'))['configs']
caps=[100,250,500,1000]
fig,axs=plt.subplots(2,4,figsize=(11,5.2))
vk=[(k,t.replace('test','validation'),p) for k,t,p in keys]
for ax,(k,tl,p) in zip(axs.flat,vk):
    for i,ver in enumerate(['v1','v2']):
        ys=[v[f'cap{c}_{ver}']['overall'][k] for c in caps]
        ax.plot(range(4),ys,color=C[i],linewidth=2,marker='o',markersize=5,label=ver.upper())
    ax.set_xticks(range(4)); ax.set_xticklabels([f'{c:,}' for c in caps])
    ax.set_title(tl,fontsize=9.5,loc='left',fontweight='bold')
    ax.yaxis.grid(True,color=GRID,linewidth=0.8); ax.set_axisbelow(True)
    ax.set_xlabel('Per-relation cap',fontsize=8)
    if p: ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0,decimals=1))
    else: ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda x,p: f'{int(x):,}'))
    if k=='precision': ax.set_ylim(0.85,1.0)
    else: ax.set_ylim(bottom=0)
axs[0,0].legend(frameon=False,fontsize=8)
fig.tight_layout(); fig.savefig(OUT+'/chart_validation_caps.png',dpi=220); plt.close(fig)
for c in caps:
  for ver in ['v1','v2']:
    o=v[f'cap{c}_{ver}']['overall']; print(c,ver,o['predictions'],o['tp_matched_positives'],o['fp_matched_supplied_negatives'],o['unlabelled_predictions'],round(o['precision'],4),round(o['recall'],4),round(o['f1'],4),round(o['positive_hit_rate'],4))
# relation freq
g=json.load(open(R+'phase2/graph_statistics.json'))['relation_frequencies'][:20][::-1]
fig,ax=plt.subplots(figsize=(8,5.6))
ax.barh(range(len(g)),[r['count'] for r in g],color=C[0],height=0.65)
ax.set_yticks(range(len(g))); ax.set_yticklabels([f"{r['label']} ({r['relation_id']})" for r in g],fontsize=8)
for i,r in enumerate(g): ax.text(r['count'],i,f" {r['count']:,}",va='center',fontsize=7.5)
ax.xaxis.grid(True,color=GRID); ax.set_axisbelow(True); ax.set_xlabel('Training triples')
ax.set_xlim(0,75000)
fig.tight_layout(); fig.savefig(OUT+'/chart_relation_frequency.png',dpi=220); plt.close(fig)
# per relation TP cap1000 v2 test
import csv
rows=list(csv.DictReader(open(R+'cap_experiment/test_final/per_relation_metrics.csv')))
rows=[r for r in rows if int(r['tp_matched_positives'])>0]
rows.sort(key=lambda r:int(r['tp_matched_positives']),reverse=True); rows=rows[:15][::-1]
lab=json.load(open('/mnt/user-data/uploads/KG-Ontology-Rule-Based-Project/outputs/phase2/graph_statistics.json'))['relation_frequencies']
L={r['relation_id']:r['label'] for r in lab}
fig,ax=plt.subplots(figsize=(8,5.2))
y=range(len(rows))
ax.barh([i+0.2 for i in y],[int(r['tp_matched_positives']) for r in rows],height=0.38,color=C[0],label='Positive test matches (TP)')
ax.barh([i-0.2 for i in y],[int(r['fp_matched_supplied_negatives']) for r in rows],height=0.38,color=C[1],label='Supplied-negative matches (FP)')
ax.set_yticks(list(y)); ax.set_yticklabels([f"{L.get(r['relation'],r['relation'])} ({r['relation']})" for r in rows],fontsize=8)
for i,r in enumerate(rows): ax.text(int(r['tp_matched_positives']),i+0.2,' '+r['tp_matched_positives'],va='center',fontsize=7)
ax.xaxis.grid(True,color=GRID); ax.set_axisbelow(True); ax.legend(frameon=False,fontsize=8,loc='lower right'); ax.set_xlabel('Triples')
fig.tight_layout(); fig.savefig(OUT+'/chart_cap1000_v2_per_relation.png',dpi=220); plt.close(fig)
print([(r['relation'],r['tp_matched_positives'],r['fp_matched_supplied_negatives'],r['predictions']) for r in rows[::-1]])
