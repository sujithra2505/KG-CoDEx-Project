import sys
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Patch
OUT=sys.argv[1]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
cols=['Jul\n2026','Aug\n2026','Sep\n2026','Oct\n2026','Nov\n2026','Future Work\n(after Nov 2026)']
W=[1,1,1,1,1,1.6]
X=[0];
for w in W[:-1]: X.append(X[-1]+w)
C={'done':'#2e8b2e','prog':'#eda100','plan':'#2a78d6'}
T=[('1. Literature Review and Problem Formulation',{0:'done',1:'done',2:'done',3:'done'}),
   ('2. Dataset Preparation and Analysis',{2:'done',3:'done'}),
   ('3. Knowledge Graph and Ontology Construction',{3:'done',5:'plan'}),
   ('4. Rule Mining and Validation',{3:'done',5:'plan'}),
   ('5. Candidate Generation and Prediction Ranking',{3:'done'}),
   ('6. Experiments and Performance Evaluation',{3:'done',5:'plan'}),
   ('7. Report Preparation and Future Improvements',{3:'prog',4:'prog',5:'plan'})]
fut={3:'ontology-aware\nscoring',4:'wider rule\ncoverage',6:'MRR/Hits@K,\nbaselines',7:'final report'}
fig,ax=plt.subplots(figsize=(8.8,4.3))
n=len(T)
for j,(x,w) in enumerate(zip(X,W)):
    ax.add_patch(Rectangle((x,0),w,n,fill=(j==5),facecolor='#f6f6f4',edgecolor='#c9c8c3',lw=0.8))
    ax.text(x+w/2,n+0.15,cols[j],ha='center',va='bottom',fontsize=10,fontweight='bold')
for i,(name,cells) in enumerate(T):
    y=n-1-i
    ax.text(-0.1,y+0.5,name,ha='right',va='center',fontsize=9.5)
    ax.axhline(y,color='#e4e3df',lw=0.8)
    for j,st in cells.items():
        x,w=X[j],W[j]
        ax.add_patch(Rectangle((x+0.06,y+0.22),w-0.12,0.56,facecolor=C[st],edgecolor='white',hatch='//' if st=='plan' else None,alpha=0.95 if st!='plan' else 0.75))
    if (i+1) in fut and 5 in cells:
        ax.text(X[5]+W[5]/2,y+0.5,fut[i+1],ha='center',va='center',fontsize=7.8,color='#0b0b0b',linespacing=0.95,bbox=dict(facecolor='white',edgecolor='none',pad=1.5))
ax.set_xlim(-4.6,sum(W)+0.05); ax.set_ylim(-0.9,n+0.8); ax.axis('off')
ax.legend(handles=[Patch(color=C['done'],label='Completed'),Patch(color=C['prog'],label='In progress'),Patch(facecolor=C['plan'],hatch='//',alpha=0.75,label='Planned (dates to be confirmed)')],
          loc='lower center',bbox_to_anchor=(0.62,-0.02),ncol=3,frameon=False,fontsize=9.5)
fig.tight_layout(); fig.savefig(OUT+'/gantt7.png',dpi=230)
