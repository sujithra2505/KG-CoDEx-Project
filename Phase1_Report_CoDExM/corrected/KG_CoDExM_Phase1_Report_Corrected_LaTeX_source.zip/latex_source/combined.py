import json, sys
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter, FuncFormatter
R='/mnt/user-data/uploads/KG-Ontology-Rule-Based-Project/outputs/'
OUT=sys.argv[1]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.edgecolor':'#9a9994','axes.labelcolor':'#52514e',
 'xtick.color':'#52514e','ytick.color':'#52514e','axes.spines.top':False,'axes.spines.right':False})
C={'v1':'#2a78d6','v2':'#eb6834'}; GRID='#e4e3df'
v=json.load(open(R+'cap_experiment/validation/validation_results.json'))['configs']
sel=json.load(open(R+'cap_experiment/selection.json'))
t=json.load(open(R+'cap_experiment/test_final/test_results.json'))['overall']
assert sel['selected']=='cap1000_v2'
caps=[100,250,500,1000]
fig,axs=plt.subplots(2,4,figsize=(10.2,5.6))
# summary card
ax=axs[0,0]; ax.axis('off')
o=v['cap1000_v2']['overall']; tb=sel['table']['cap1000_v2']
lines=[('Selected configuration',''),('cap 1,000 · ranking V2',None),
('Validation (selection split)',''),
 (f"Benchmark precision  {o['precision']*100:.2f}%",None),
 (f"Wilson lower bound  {tb['precision_wilson_lower']*100:.2f}%",None),
 (f"   floor (cap-100 V2 − 0.05)  {tb['threshold']*100:.2f}%",None),
 (f"Recall  {o['recall']*100:.2f}%   F1  {o['f1']*100:.2f}%",None),
 (f"Positive hit rate  {o['positive_hit_rate']*100:.2f}%",None),
 ('Final test (second test use)',''),
 (f"Precision {t['precision']*100:.2f}%  Recall {t['recall']*100:.2f}%",None),
 (f"F1 {t['f1']*100:.2f}%  Hit rate {t['positive_hit_rate']*100:.2f}%",None)]
y=1.0
for txt,h in lines:
    if h=='' : ax.text(-0.14,y,txt,fontsize=8.2,fontweight='bold',color='#0b0b0b',transform=ax.transAxes); y-=0.085
    else: ax.text(-0.12,y,txt,fontsize=7.6,color='#3d3d3a',transform=ax.transAxes); y-=0.085
    if txt.startswith('cap 1,000') or txt.startswith('Positive hit'): y-=0.04
keys=[('predictions','Predictions kept',0),('tp_matched_positives','Positive matches (TP)',0),('fp_matched_supplied_negatives','Negative matches (FP)',0),
('precision','Benchmark precision',1),('recall','Recall',1),('f1','F1-score',1),('positive_hit_rate','Positive hit rate',1)]
for ax,(k,tl,p) in zip(list(axs.flat)[1:],keys):
    for ver in ['v1','v2']:
        ys=[v[f'cap{c}_{ver}']['overall'][k] for c in caps]
        ax.plot(range(4),ys,color=C[ver],lw=2,marker='o',ms=5,label=ver.upper())
    yv=v['cap1000_v2']['overall'][k]
    ax.plot([3],[yv],marker='o',ms=13,mfc='none',mec='#0b0b0b',mew=1.6)
    if k=='precision':
        lw=[sel['table'][f'cap{c}_v2']['precision_wilson_lower'] for c in caps]
        ax.plot(range(4),lw,color=C['v2'],lw=1.2,ls=':',label='V2 Wilson lower bound')
        ax.axhline(sel['table']['cap1000_v2']['threshold'],color='#e34948',lw=1,ls='--',label='V2 floor (rule A1)')
        ax.set_ylim(0.80,0.99); ax.legend(frameon=False,fontsize=6.6,loc='lower right',ncol=2,handlelength=1.5,columnspacing=0.8)
    else: ax.set_ylim(bottom=0)
    ax.set_xticks(range(4)); ax.set_xticklabels(['100','250','500','1,000'])
    ax.set_title(tl,loc='left',fontsize=9.5,fontweight='bold',color='#0b0b0b')
    ax.yaxis.grid(True,color=GRID); ax.set_axisbelow(True)
    ax.yaxis.set_major_formatter(PercentFormatter(1.0,decimals=1) if p else FuncFormatter(lambda x,_: f'{int(x):,}'))
    ax.set_xlabel('per-relation cap',fontsize=8.5)
axs[0,1].legend(frameon=False,fontsize=8.5)
fig.text(0.02,0.012,'Black ring: configuration selected by rule A1 (cap 1,000, V2). All values from the validation split except the final-test lines of the summary.',fontsize=8.5,color='#52514e')
fig.tight_layout(rect=(0,0.03,1,1))
fig.savefig(OUT+'/KG_CoDExM_Cap_Comparison_Validation.png',dpi=230)
